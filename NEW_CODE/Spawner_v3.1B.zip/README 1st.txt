
Change notes: OLD
* Removed need for custom mission.sqm to be added should be more map friendly now
* Removed damage.sqf due to move of damage code into generate_zone.sqf
* Removed repacked files form GitHub - Work is holding me up I cant keep this updated on patch days
* Settings in ZOM\init.sqf have been updated
* Handle Damage function added - kinda works is buggy on old mod versions - unused if using zRLogic
* Use Ryan's Mod logic added "zRLogic" to settings for when Ryan updates the mod script will then use zombie damage from Ryan's mod
* Added search setting for A2 buildings you can enable that in settings - used if zombies are not spawning for you on A2 Maps
* Added setting to make Mission AI attack Zombies again - can cause FPS issues if on 

Change notes: NEW
* Updated community triggers
* New Setting to remove AI from trader zones
* Fixed reported _back RPT error

Install has had a slight change see Setup below: - TIP! Always update Zombies & Demons 1st
1. Download the script - https://github.com/rscaptainjack/ZOMBIES_CODE
2. unpack your mpmission of choice
3. Add folder ZOM to your mpmission of choice
4. Add this to top of initPlayerLocal.sqf or custom init.sqf

  [] execVM "ZOM\init.sqf";
  
5. repack mpmission of choice
6. unpack server exile_server_config.pbo
7. add this to mission.sqm in mpmission folder

To stop player connecting to server without mods edit mission.sqm in mpmissions add below to addOns[] 
	addOns[] = {"exile_client", "a3_map_altis", "ryanzombies"};
	
8. Download/Update Zombies & Demons Mod + key to server folder Download Here: http://www.armaholic.com/page.php?id=28958
9. Load server with parameters:  -mod=@Exile;@Ryanzombies 


BE Filters: 
scripts.txt add to execVM line
!="ZOM\generate_zone.sqf" !="ZOM\init.sqf" !="ZOM\walk.sqf" !="zom_fuc_realDamagehandler"

createvehicle.txt
!="C_man_polo" !="RyanZombieC_man_1" !="RyanZombieC_man_polo_1" !="RyanZombieC_man_polo_2" !="RyanZombieC_man_polo_4" !="RyanZombieC_man_polo_5" !="RyanZombieC_man_polo_6" !="RyanZombieC_man_p_fugitive" !="RyanZombieC_man_w_worker" !="RyanZombieC_scientist_"" !="RyanZombieC_man_hunter_1" !="RyanZombieC_man_pilot" !="RyanZombieC_journalist" !="RyanZombieC_Orestesslow" !="RyanZombieC_Nikosslow" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_02_f" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03w" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_lite" !="RyanZombieB_Soldier_lite_F" !="RyanZombieboss1" !="RyanZombieB_RangeMaster_Fmedium" !="RyanZombieSpider1"

setpos.txt - add all to stop the client kicks for zombie movement
1 "" !"Exile_" !="RyanZombieC_man_1" !="RyanZombieC_man_polo_1" !="RyanZombieC_man_polo_2" !="RyanZombieC_man_polo_4" !="RyanZombieC_man_polo_5" !="RyanZombieC_man_polo_6" !="RyanZombieC_man_p_fugitive" !="RyanZombieC_man_w_worker" !="RyanZombieC_scientist_"" !="RyanZombieC_man_hunter_1" !="RyanZombieC_man_pilot" !="RyanZombieC_journalist" !="RyanZombieC_Orestesslow" !="RyanZombieC_Nikosslow" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_02_f" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03w" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_lite" !="RyanZombieB_Soldier_lite_F" !="RyanZombieboss1" !="RyanZombieB_RangeMaster_Fmedium" !="RyanZombieSpider1"
