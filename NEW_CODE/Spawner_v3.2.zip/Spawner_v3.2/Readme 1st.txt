What is this script? it's a unit spawner script used to spawn in AI in any map it's setup to be easy to use in this case it's been used as
a zombie spawner for Ryans Zombies and Demons it can do so much more it can also spawn AI from other mods. 


Spawner_v3.2.zip - Features: Most of this update is optimization
* Can now choose to have AI walk (move around) or stand still and wait
* Changes to Headless Client settings 
* Updated note on ZOMcivilianside
* Settings on spawn size optimized by default
* Advanced FPS Settings added - is optional and not needed
* New Setting to remove AI from trader zones
* Fixed reported _back RPT error
* Updated community triggers

For script settings edit ZOM\init.sqf

1. unpack your mpmission of choice
2. Add folder ZOM to your mpmission of choice
3. Add this to top of initPlayerLocal.sqf or custom init.sqf

  [] execVM "ZOM\init.sqf";
  
4. repack mpmission of choice


To stop player connecting to server without mods edit mission.sqm in mpmissions add below to addOns[] 

	addOns[] = {"exile_client", "a3_map_altis", "ryanzombies"};


BE Filters: 
scripts.txt add to execVM line
!="ZOM\generate_zone.sqf" !="ZOM\init.sqf" !="ZOM\walk.sqf" !="zom_fuc_realDamagehandler"

createvehicle.txt
!="C_man_polo" !="RyanZombieC_man_1" !="RyanZombieC_man_polo_1" !="RyanZombieC_man_polo_2" !="RyanZombieC_man_polo_4" !="RyanZombieC_man_polo_5" !="RyanZombieC_man_polo_6" !="RyanZombieC_man_p_fugitive" !="RyanZombieC_man_w_worker" !="RyanZombieC_scientist_"" !="RyanZombieC_man_hunter_1" !="RyanZombieC_man_pilot" !="RyanZombieC_journalist" !="RyanZombieC_Orestesslow" !="RyanZombieC_Nikosslow" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_02_f" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03w" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_lite" !="RyanZombieB_Soldier_lite_F" !="RyanZombieboss1" !="RyanZombieB_RangeMaster_Fmedium" !="RyanZombieSpider1"

setpos.txt - add all to stop the client kicks for zombie movement
1 "" !"Exile_" !="RyanZombieC_man_1" !="RyanZombieC_man_polo_1" !="RyanZombieC_man_polo_2" !="RyanZombieC_man_polo_4" !="RyanZombieC_man_polo_5" !="RyanZombieC_man_polo_6" !="RyanZombieC_man_p_fugitive" !="RyanZombieC_man_w_worker" !="RyanZombieC_scientist_"" !="RyanZombieC_man_hunter_1" !="RyanZombieC_man_pilot" !="RyanZombieC_journalist" !="RyanZombieC_Orestesslow" !="RyanZombieC_Nikosslow" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_02_f" !="RyanZombieB_Soldier_02" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03" !="RyanZombieB_Soldier_03w" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_04" !="RyanZombieB_Soldier_lite" !="RyanZombieB_Soldier_lite_F" !="RyanZombieboss1" !="RyanZombieB_RangeMaster_Fmedium" !="RyanZombieSpider1"